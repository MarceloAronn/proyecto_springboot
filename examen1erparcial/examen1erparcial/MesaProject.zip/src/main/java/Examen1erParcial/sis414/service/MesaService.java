package Examen1erParcial.sis414.service;

import Examen1erParcial.sis414.model.Mesa;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class MesaService {
    private final List<Mesa> listaMesas = new ArrayList<>();

    public MesaService() {
        listaMesas.add(new Mesa(1, "Madera", 4, "Rectangular"));
        listaMesas.add(new Mesa(2, "Metal", 6, "Redonda"));
    }

    public List<Mesa> obtenerMesas() {
        return listaMesas;
    }

    public Mesa obtenerMesaPorId(int id) {
        return listaMesas.stream()
                .filter(m -> m.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void agregarMesa(Mesa mesa) {
        listaMesas.add(mesa);
    }
}
