package Examen1erParcial.sis414.controller;

import Examen1erParcial.sis414.model.Mesa;
import Examen1erParcial.sis414.service.MesaService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/mesas")
public class MesaController {
    private final MesaService mesaService;

    public MesaController(MesaService mesaService) {
        this.mesaService = mesaService;
    }

    @GetMapping
    public List<Mesa> getMesas() {
        return mesaService.obtenerMesas();
    }

    @GetMapping("/{id}")
    public Mesa getMesaById(@PathVariable int id) {
        return mesaService.obtenerMesaPorId(id);
    }

    @PostMapping
    public String addMesa(@RequestBody Mesa mesa) {
        mesaService.agregarMesa(mesa);
        return "Mesa agregada con éxito";
    }
}
